#!/usr/bin/env python3
"""
Polymarket Daily — digest generator.

Pulls live markets from the Polymarket Gamma API and emits a markdown digest:
  1. Biggest 24h movers (by absolute price change, liquidity floor applied)
  2. Highest-volume markets of the day
  3. Long odds / notable pricing

Usage:
    python3 digest.py                  # print markdown to stdout
    python3 digest.py --out issue.md   # write markdown to a file
    python3 digest.py --top 12         # how many markets per section

No API key required. Public Gamma API.
"""
import argparse
import datetime as dt
import json
import urllib.parse
import urllib.request

GAMMA = "https://gamma-api.polymarket.com/markets"


def fetch(params):
    url = f"{GAMMA}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": "polymarket-daily/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def pct(x):
    try:
        return f"{float(x) * 100:.1f}%"
    except (TypeError, ValueError):
        return "—"


def yes_price(m):
    """Return the 'Yes'/first-outcome price and label."""
    try:
        outcomes = json.loads(m.get("outcomes") or "[]")
        prices = json.loads(m.get("outcomePrices") or "[]")
        if outcomes and prices:
            return outcomes[0], float(prices[0])
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return None, None


def money(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "—"
    if v >= 1_000_000:
        return f"${v / 1_000_000:.1f}M"
    if v >= 1_000:
        return f"${v / 1_000:.0f}k"
    return f"${v:.0f}"


def clean_question(m):
    q = (m.get("question") or "").strip()
    return q if len(q) <= 120 else q[:117] + "…"


def collect(top, min_liquidity=2000):
    raw = fetch({
        "closed": "false",
        "active": "true",
        "limit": 300,
        "order": "volume24hr",
        "ascending": "false",
    })
    markets = []
    for m in raw:
        try:
            if float(m.get("liquidityNum") or m.get("liquidity") or 0) < min_liquidity:
                continue
        except (TypeError, ValueError):
            continue
        label, price = yes_price(m)
        if price is None:
            continue
        markets.append({
            "q": clean_question(m),
            "label": label,
            "price": price,
            "chg1d": m.get("oneDayPriceChange"),
            "chg1w": m.get("oneWeekPriceChange"),
            "vol24": m.get("volume24hr"),
            "vol": m.get("volume"),
            "end": (m.get("endDateIso") or m.get("endDate") or "")[:10],
            "slug": m.get("slug") or "",
            "url": f"https://polymarket.com/event/{m.get('slug')}" if m.get("slug") else "",
        })

    def fnum(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return 0.0

    movers = sorted(
        [m for m in markets if m["chg1d"] is not None],
        key=lambda m: abs(fnum(m["chg1d"])),
        reverse=True,
    )[:top]
    volume = sorted(markets, key=lambda m: fnum(m["vol24"]), reverse=True)[:top]
    longshots = sorted(
        [m for m in markets if 0.02 <= m["price"] <= 0.15 and fnum(m["vol24"]) > 20000],
        key=lambda m: fnum(m["vol24"]),
        reverse=True,
    )[:6]
    return markets, movers, volume, longshots


def render(markets, movers, volume, longshots, top):
    today = dt.date.today().strftime("%d %b %Y")
    out = [f"# Polymarket Daily — {today}", ""]
    out += [f"_{len(markets)} active markets screened · "
            f"generated {dt.datetime.now().strftime('%H:%M')} local_", ""]

    out += ["## 📈 Biggest 24h movers", ""]
    if not movers:
        out += ["_No qualifying moves today._", ""]
    for m in movers:
        arrow = "▲" if float(m["chg1d"] or 0) > 0 else "▼"
        out += [
            f"- **{m['q']}** — {m['label']} {pct(m['price'])} "
            f"({arrow} {pct(abs(float(m['chg1d'] or 0)))} in 24h; "
            f"{money(m['vol24'])} traded; resolves {m['end'] or 'TBD'})",
            f"  {m['url']}",
        ]
    out += [""]

    out += ["## 💰 Where the money is (24h volume)", ""]
    for m in volume:
        out += [
            f"- **{m['q']}** — {m['label']} {pct(m['price'])} · "
            f"{money(m['vol24'])} in 24h · {money(m['vol'])} all-time"
        ]
    out += [""]

    if longshots:
        out += ["## 🎯 Long odds with real money behind them", ""]
        for m in longshots:
            out += [
                f"- **{m['q']}** — {m['label']} priced {pct(m['price'])} "
                f"({money(m['vol24'])} traded in 24h)" + (f" · {m['url']}" if m["url"] else "")
            ]
        out += [""]

    out += ["## 🧠 Why it matters", "",
            "<!-- LLM prompt: for each of the top 3 movers above, explain in 1-2 sentences "
            "what news moved it and whether the move looks like information or noise. "
            "Add one line connecting the theme across markets. No hype. -->", ""]
    out += ["---", "", "Not financial advice. Odds are market prices, not probabilities.",
            "Sources: Polymarket public API."]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=8)
    ap.add_argument("--out", default=None)
    ap.add_argument("--json", default=None, help="also dump raw market data to JSON")
    args = ap.parse_args()

    markets, movers, volume, longshots = collect(args.top)
    md = render(markets, movers, volume, longshots, args.top)

    if args.out:
        with open(args.out, "w") as fh:
            fh.write(md)
        print(f"wrote {args.out} ({len(markets)} markets screened)")
    else:
        print(md)

    if args.json:
        with open(args.json, "w") as fh:
            json.dump({"movers": movers, "volume": volume, "longshots": longshots}, fh, indent=2)
        print(f"wrote {args.json}")


if __name__ == "__main__":
    main()
